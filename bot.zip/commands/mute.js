const Discord = require('discord.js');

exports.run = async (client, message, args) => {
let cargomuted = message.guild.roles.cache.get('791012120439160842')
const member = message.mentions.members.first()
if (!message.author.hasPermission('MANAGE_ROLES')) {
    await message.channel.send('Você não tem permissão para efetuar o comando')
} else if (message.author.hasPermission('MANAGE_ROLES')) {
    await member.roles.add(cargomuted)
    await message.channel.send('Usuário Mutado')


}




}