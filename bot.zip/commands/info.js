const Discord = require('discord.js');

exports.run = async (client, message, args) => {

    await message.channel.send('**Desenvolvido por ySnow#1103, meu prefixo é ss!**')

}